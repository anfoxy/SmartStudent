package com.example.studentapp.db;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Subjects {

    @SerializedName("id_Subject")
    private int id;
    @SerializedName("subject_Name")
    private String name;
    @SerializedName("subject_Date")
    private String days;
    @SerializedName("is_Completed")
    private boolean completed;
    @SerializedName("user_Id")
    private int userId;
    @SerializedName("questions")
    private ArrayList<Questions> questions;

    public Subjects(int id, String name, String days, boolean completed, int userId, ArrayList<Questions> questions) {
        this.id = id;
        this.name = name;
        this.days = days;
        this.completed = completed;
        this.userId = userId;
        this.questions = questions;
    }

    public ArrayList<Questions> getQuestions() {
        return questions;
    }

    public void setQuestions(ArrayList<Questions> questions) {
        this.questions = questions;
    }

    public String getDaysString() {
        return days;
    }

    public void setDaysString(String days) {
        this.days = days;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
